# Tugas SCSS
Hasil konversi dari index(2).html dan style.css.
Pola 7-1, @use/@forward, variables, mixins, nesting, @each, @for, responsive.
Jalankan: npm install lalu npm run dev.
